--1-supplier with minimum average supplier lead time
select sup_name,AVG(supplier_lt) as average_s_lead_time
from all_data
group by sup_name
order by average_s_lead_time

--2-supplier with maximum sum of products sold
select sup_name,sum(no_prod_sold) as total_no_products_sold
from all_data
group by sup_name
order by sum(no_prod_sold) desc

--3-supplier with minimum average other costs
select sup_name,avg(other_costs) as average_other_costs
from all_data
group by sup_name
order by avg(other_costs)

--4-supplier with maximum total revenue
select sup_name,sum(revenue) as total_revenue
from all_data
group by sup_name
order by sum(revenue) desc

--5-supplier with maximum total profit
select sup_name,sum(profit) as total_profit
from all_data
group by sup_name
order by sum(profit) desc

--6-supplier with maximum total profit margin
select sup_name,sum(profit_margin) as total_profit_margin
from all_data
group by sup_name
order by sum(profit_margin) desc

--7-supplier with lowest average defect rate
select sup_name,avg(def_rate) as average_defect_rate
from all_data
group by sup_name
order by avg(def_rate)


--supplier with highest pass rate

alter table all_data add fail int, pending int, pass int

update all_data
set fail=1
where inspect_resl = 'Fail'

update all_data
set fail=0
where inspect_resl = 'Pending'

update all_data
set fail=0
where inspect_resl = 'Pass'

select inspect_resl,fail from all_data


update all_data
set pending=1
where inspect_resl = 'Pending'

update all_data
set pending=0
where inspect_resl = 'Fail'

update all_data
set pending=0
where inspect_resl = 'Pass'

select inspect_resl,pending from all_data

update all_data
set pass=1
where inspect_resl = 'Pass'

update all_data
set pass=0
where inspect_resl = 'Fail'

update all_data
set pass=0
where inspect_resl = 'Pending'

select inspect_resl,pass from all_data

select sup_name,sum(pass),sum(pending),sum(fail)
from all_data
group by sup_name

select sup_name,count(*) from all_data
group by sup_name

--8- if i put sum(pass)/count(*) * 100, it gives 0, i don't know why??
select sup_name,sum(pass)*100/count(*) as pass_per,sum(pending)*100/count(*) as pending_per,sum(fail)*100/count(*) as fail_per
from all_data
group by sup_name


--chatgpt code
select sup_name,
SUM(CASE WHEN inspect_resl = 'Fail' THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS Fail,
SUM(CASE WHEN inspect_resl = 'Pending' THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS Pending,
SUM(CASE WHEN inspect_resl = 'Pass' THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS Pass
from all_data
group by sup_name


--9-total order quantity by distribution location
select delv_location,sum(order_qun) as total_order_quantity
from all_data
group by delv_location
order by total_order_quantity desc

select sup_name,delv_location,sum(order_qun) as total_order_quantity
from all_data
group by sup_name,delv_location
order by total_order_quantity ,sup_name



--supply chain performance
--10-least 10 products in supply cahin lowest total cost
select top 10 total_costs,SKU
from all_data
order by total_costs


--11-most 10 products costs in supply cahin 
select top 10 total_costs,SKU
from all_data
order by total_costs desc

--12-top 10 products in supply cahin lowest lead time
select top 10 total_times,SKU
from all_data
order by total_times

--13-most 10 products times in supply cahin 
select top 10 total_times,SKU
from all_data
order by total_times desc

--14-category product has lowest costs
select p_type,avg(total_costs) as average_total_costs
from all_data
group by p_type
order by average_total_costs

--15-category product has lowest lead time
select p_type,avg(total_times) as average_total_times
from all_data
group by p_type
order by average_total_times

--16-most 10 products profit marginal in supply cahin 
select top 10 profit_margin,SKU
from all_data
order by profit_margin desc